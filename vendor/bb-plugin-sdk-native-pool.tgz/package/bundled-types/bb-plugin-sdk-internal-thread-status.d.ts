// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import { z } from 'zod';

declare const environmentWorkspaceDisplayKindSchema: z.ZodEnum<{
    "managed-worktree": "managed-worktree";
    "unmanaged-worktree": "unmanaged-worktree";
    other: "other";
}>;
type EnvironmentWorkspaceDisplayKind = z.infer<typeof environmentWorkspaceDisplayKindSchema>;

declare const threadStatusSchema: z.ZodEnum<{
    active: "active";
    error: "error";
    idle: "idle";
    pending: "pending";
    starting: "starting";
    stopping: "stopping";
}>;
type ThreadStatus = z.infer<typeof threadStatusSchema>;

declare const threadParentNotificationsSchema: z.ZodEnum<{
    auto: "auto";
    off: "off";
    stuck: "stuck";
}>;
type ThreadParentNotifications = z.infer<typeof threadParentNotificationsSchema>;

declare const threadRuntimeDisplayStatusSchema: z.ZodEnum<{
    "waiting-for-host": "waiting-for-host";
    active: "active";
    error: "error";
    idle: "idle";
    pending: "pending";
    provisioning: "provisioning";
    starting: "starting";
    stopping: "stopping";
}>;

/**
 * The three additions to {@link threadStatusValues} are display-only: they
 * refine `active`/`idle` with host and workspace facts the durable status does
 * not record.
 *
 * A never-started thread needs no such refinement — `pending` is a real thread
 * status now, so it travels to the client as itself. It used to arrive as a
 * separate `held` display status, derived from an `idle` thread holding a live
 * dispatch hold; that derivation and the holds behind it are both gone.
 */
type ThreadRuntimeDisplayStatus = z.infer<typeof threadRuntimeDisplayStatusSchema>;
declare const threadQueuedWorkSchema: z.ZodEnum<{
    failed: "failed";
    none: "none";
    waiting: "waiting";
}>;
type ThreadQueuedWork = z.infer<typeof threadQueuedWorkSchema>;

/**
 * A name the host resolves to a glyph, in this order: a name any plugin
 * registered with `app.experimental_icons.register()`, then a built-in BB icon
 * name (`"Zap"`), then a namespaced `"<pluginId>/<name>"` glyph naming an
 * entry of that plugin's manifest `bb.branding.experimental_icons` map. A
 * registration therefore shadows a built-in, and either shadows a declared
 * icon of the same name. Names that resolve to none of the three fall back to
 * the surface's generic icon.
 *
 * Declared icons and registrations are one vocabulary here: the same name
 * works in `experimental_Icon`, in every field below, and — for a declared
 * icon — in the tool, provider and bridge-row declarations that accept one.
 * Declared icons need no frontend bundle and survive the plugin being stopped;
 * registrations can be any React component but live only while the plugin's
 * app bundle is loaded.
 */
type BbIconName = string;
/**
 * The one status bb would paint for a thread, already resolved through the
 * host's precedence (attention before work; plan mode before the generic
 * spinner). Draw it with {@link PluginSdkApp.experimental_ThreadStatusGlyph},
 * or resolve a row that folds in more through
 * {@link PluginSdkApp.experimental_resolveThreadStatus}.
 *
 * Treat an unrecognized value as "none": bb adds kinds over time, and an
 * older plugin must degrade to drawing nothing rather than throwing.
 *
 * "draft" and "working-draft" are never reported here: an unsubmitted composer
 * draft is per-client state the host reads per row, which an array-wide view
 * cannot. A thread holding a draft reports whatever it would report without
 * one. "queued-failed" and "queued-waiting" are reported, with the same
 * precedence bb's list uses (a failed send outranks the unread dot; a waiting
 * message ranks just below it).
 */
type PluginSidebarThreadIndicator = "background-agent" | "background-command" | "draft" | "none" | "plan-mode" | "queued-failed" | "queued-waiting" | "runtime" | "unread-error" | "unread-success" | "waiting-for-input" | "workflow" | "working-draft";
/** Live work counts on a thread. All zero means nothing is running. */
interface PluginSidebarThreadActivity {
    workflows: number;
    backgroundAgents: number;
    backgroundCommands: number;
    planMode: number;
}
/**
 * One thread in the sidebar's live view.
 *
 * A deliberate copy of the fields a sidebar needs — not a re-export of the
 * host's internal thread row type, which changes whenever the app needs a
 * field. Timestamps are epoch milliseconds.
 */
interface PluginSidebarThread {
    id: string;
    projectId: string;
    /** Null while a thread is still unnamed; pair with `titleFallback`. */
    title: string | null;
    titleFallback: string | null;
    /**
     * What bb shows for this thread as plain text: `title`, else
     * `titleFallback`, else a short id, with any `@project:`, `@section:`, and
     * `@thread:` mentions in it resolved to their names. Sort on it and use it
     * for accessible names; render {@link PluginSdkApp.ThreadTitle} for the
     * same text with mention chips.
     */
    displayTitle: string;
    /** The thread this one was forked from or spawned under; null at the root. */
    parentThreadId: string | null;
    /**
     * The thread whose lifecycle this one follows (a delegated child stops
     * when its owner stops); null when the thread owns its own lifecycle.
     */
    lifecycleOwnerThreadId: string | null;
    /**
     * Which of this child's outcomes wake its parent: "auto" (every outcome),
     * "stuck" (failures, interruptions, and blockers), or "off".
     */
    parentNotifications: ThreadParentNotifications;
    /** The thread this one was forked from; null unless `originKind` is "fork". */
    sourceThreadId: string | null;
    sectionId: string | null;
    /** How this thread came to exist under its parent; null for root threads. */
    originKind: "fork" | null;
    /** The plugin that spawned it, or null for non-plugin origins. */
    originPluginId: string | null;
    /** The agent provider this thread runs on; resolve it through
     * {@link PluginSdkApp.experimental_useProviders} for a name and icon. */
    providerId: string;
    /**
     * The thread's execution status. bb's list sorts busy threads ("starting",
     * "active", "stopping") above idle ones. Treat an unknown value as "idle".
     */
    status: ThreadStatus;
    /**
     * `status` refined by host and environment state: adds "provisioning" and
     * "waiting-for-host" for a thread whose machine is not ready. Treat an
     * unknown value as `status`.
     */
    runtimeStatus: ThreadRuntimeDisplayStatus;
    /**
     * Whether a message is queued behind the running turn ("waiting") or a
     * queued message failed to send ("failed"). "none" otherwise.
     */
    queuedWork: ThreadQueuedWork;
    /** The agent is blocked on the user: an approval or a question. */
    hasPendingInteraction: boolean;
    activity: PluginSidebarThreadActivity;
    indicator: PluginSidebarThreadIndicator;
    /**
     * The host's accessible label for `indicator`, e.g. "Thread needs user
     * input"; null when the indicator is "none". Use it for `aria-label` so
     * screen-reader text stays consistent across sidebars.
     */
    indicatorLabel: string | null;
    isUnread: boolean;
    isPinned: boolean;
    /** When the thread was pinned (epoch ms); null when unpinned. */
    pinnedAt: number | null;
    /**
     * The user's manual order among pinned threads (lexicographic, ascending);
     * null for an unpinned thread or a pin that has never been reordered, which
     * bb's list sorts after keyed pins by `pinnedAt`.
     */
    pinSortKey: string | null;
    isArchived: boolean;
    /** When the thread was archived (epoch ms); null when not archived. */
    archivedAt: number | null;
    /**
     * The app-relative URL bb opens for this thread, e.g.
     * `/projects/<projectId>/threads/<id>`. Put it on your row's anchor: the
     * host routes a plain click in place, and middle-click, copy-link, and
     * open-in-new-window work without further code.
     */
    href: string;
    /**
     * True for threads bb keeps out of its own list (internal helper threads a
     * plugin spawned with `visibility: "hidden"`). The array includes them so a
     * list that wants them can show them; bb's list filters them out.
     */
    isHidden: boolean;
    environment: {
        id: string | null;
        name: string | null;
        branchName: string | null;
        /** The checkout's absolute path on its host; null when unknown. */
        path: string | null;
        /**
         * True when the environment is a git worktree, which is what bb's
         * "group by environment" clusters; false for a plain checkout; null when
         * unknown.
         */
        isWorktree: boolean | null;
        /**
         * The id of the environment provider that produced this environment, or
         * null for a project's own checkout. Resolve it against
         * `GET /system/environment-providers` for a display name and icon.
         */
        providerId: string | null;
        /** @deprecated Use providerId and the environment provider catalog instead. */
        workspaceDisplayKind: EnvironmentWorkspaceDisplayKind | null;
    } | null;
    /**
     * The machine this thread's work runs on, with the name resolved for you.
     * Null when the thread has no environment yet, or when its host is not in
     * the known-hosts list. Useful where a thread has no branch to show — a
     * personal-project thread has a machine but no worktree.
     */
    host: {
        id: string;
        name: string;
    } | null;
    createdAt: number;
    updatedAt: number;
    lastReadAt: number | null;
    latestAttentionAt: number;
}
/**
 * The fields of a {@link PluginSidebarThread} that
 * {@link PluginSdkApp.experimental_resolveThreadStatus} reads.
 * An optional indicator preserves derived waiting-for-input attention when
 * resolving a sidebar DTO whose native interaction state remains raw.
 */
type PluginThreadStatusThread = Pick<PluginSidebarThread, "activity" | "hasPendingInteraction" | "isUnread" | "parentThreadId" | "queuedWork" | "runtimeStatus" | "status"> & Partial<Pick<PluginSidebarThread, "indicator">>;
/** Input for {@link PluginSdkApp.experimental_resolveThreadStatus}. */
interface PluginThreadStatusInput {
    /**
     * The row's own thread, or null for a group row (a collapsed section,
     * project, or environment) that stands only for `hiddenThreads`.
     */
    thread: PluginThreadStatusThread | null;
    /**
     * Threads the row stands for while they are hidden, such as a collapsed
     * parent's sub-threads. Their attention and work count toward the row;
     * their queued messages do not. Pass an empty array when nothing is hidden.
     */
    hiddenThreads: readonly PluginThreadStatusThread[];
    /**
     * Whether the composer holds an unsent draft for `thread` or any of
     * `hiddenThreads` (see {@link PluginSdkApp.useSidebarThreadDraft}).
     */
    hasUnsubmittedDraft: boolean;
    /**
     * The status another plugin set on the row (see
     * {@link PluginSdkApp.useSidebarThreadRowStatus}), or null.
     */
    rowStatus: PluginSidebarThreadRowStatus | null;
}
/** What bb's lists draw for a row (see {@link PluginThreadStatusInput}). */
interface PluginThreadStatus {
    indicator: PluginSidebarThreadIndicator;
    /**
     * The input `rowStatus` when it shows in place of `indicator`: it replaces
     * every indicator except "runtime", "unread-error", and
     * "waiting-for-input". Null otherwise.
     */
    rowStatus: PluginSidebarThreadRowStatus | null;
    /**
     * The accessible label for what shows: `rowStatus`'s label, else the
     * indicator's; null when nothing shows.
     */
    label: string | null;
    /**
     * Whether the row's thread or a hidden thread is working, or the input
     * `rowStatus` has the "running" tone.
     */
    isWorking: boolean;
}
/**
 * The status another plugin's app-wide script set on a thread's row through
 * the content-script context's `experimental_setThreadRowStatus` (see
 * {@link PluginSdkApp.useSidebarThreadRowStatus}). bb's row draws it in
 * place of the draft glyph while it is set; a replaced list should do the
 * same so a status set by, say, the drafts or workflows plugin does not
 * vanish when the list changes hands.
 */
type PluginSidebarThreadRowStatus = PluginComposerThreadRowStatus;
/** Host-rendered status that temporarily replaces a thread's draft glyph. */
interface PluginComposerThreadRowStatus {
    /**
     * Always drawn as given: unlike the plugin-badged surfaces, this one has no
     * preference for the plugin's own `bb.branding.icon`.
     */
    icon: BbIconName;
    /** Accessible label for the status glyph. */
    label: string;
    /**
     * Semantic host treatment for the status glyph. `running` automatically
     * shimmers; terminal `success` and `error` tones are static. Defaults to the
     * neutral tone.
     */
    tone?: "default" | "error" | "running" | "success";
}

declare function threadIndicatorLabel(indicator: PluginSidebarThreadIndicator): string | null;
declare function visibleThreadRowStatus(indicator: PluginSidebarThreadIndicator, rowStatus: PluginSidebarThreadRowStatus | null): PluginSidebarThreadRowStatus | null;
declare function experimental_resolveThreadStatus({ thread, hiddenThreads, hasUnsubmittedDraft, rowStatus, }: PluginThreadStatusInput): PluginThreadStatus;

export { experimental_resolveThreadStatus, threadIndicatorLabel, visibleThreadRowStatus };
