// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

import * as _get_bb_plugin_sdk from '@get-bb/plugin-sdk';
import { ExperimentalSidebarFooterActionContext, ExperimentalSidebarFooterItemRegistration, PluginSidebarFooterActionRegistration, PluginHomepageSectionRegistration, PluginSettingsSectionRegistration, ExperimentalAppOverlayRegistration, ExperimentalModalRegistration, InternalDoNotUseSetupGuideSectionRegistration, PluginNavPanelRegistration, ExperimentalTabRegistration, PluginNewThreadPanelActionRegistration, ComposerCustomization, PluginPendingInteractionRegistration, PluginThreadListRegistration, ExperimentalSidebarNavigationRegistration, ExperimentalSidebarNavigationPlacement, ExperimentalThreadContextSegmentRegistration, ExperimentalThreadInfoRowRegistration, ExperimentalThreadRowMetadataRegistration, ExperimentalThreadInfoSectionRegistration, ExperimentalThreadContextCardRowRegistration, ExperimentalThreadContextCardSectionRegistration, PluginThreadActionRegistration, ExperimentalPluginBrowserToolbarActionRegistration, PluginFileOpenerRegistration, PluginSourceCodeRendererRegistration, PluginDiffRendererRegistration, ExperimentalComposerRegistration, PluginMessageDirectiveRegistration, ExperimentalCodeFenceRendererRegistration, PluginMessageActionRegistration, ExperimentalMessageMetadataRegistration, PluginCommandRegistration, ExperimentalComposerCommandRegistration, PluginProviderIconRegistration, ExperimentalIconRegistration, PluginTimelineRendererRegistration, PluginEnvironmentProviderInputsRegistration, PluginMachineProviderInputsRegistration, PluginContentScriptRegistration, ExperimentalThreadDisplayPolicyResolver, PluginAppDefinition } from '@get-bb/plugin-sdk';
import { ComponentType } from 'react';
import { z } from 'zod';

type ExperimentalSidebarFooterCommandKind = "close" | "open" | "toggle";
interface ExperimentalSidebarFooterRuntimeSnapshot {
    command: {
        sequence: number;
        kind: ExperimentalSidebarFooterCommandKind;
    } | null;
}
interface ExperimentalSidebarFooterItemRuntime {
    subscribe(listener: () => void): () => void;
    getSnapshot(): ExperimentalSidebarFooterRuntimeSnapshot;
    acknowledgeCommand(sequence: number): void;
}
type CollectedExperimentalSidebarFooterItem = ExperimentalSidebarFooterItemRegistration & {
    runtime: ExperimentalSidebarFooterItemRuntime;
};
type CollectedManagedSidebarFooterItem = CollectedExperimentalSidebarFooterItem & {
    source: "experimental_sidebarFooter";
};
interface CollectedCompatibilitySidebarFooterItem {
    source: "sidebarFooterAction";
    id: string;
    label: string;
    icon: string;
    kind: "action";
    onActivate(context: ExperimentalSidebarFooterActionContext): void | Promise<void>;
    runtime: ExperimentalSidebarFooterItemRuntime;
}
type CollectedSidebarFooterItem = CollectedCompatibilitySidebarFooterItem | CollectedManagedSidebarFooterItem;
declare function adaptSidebarFooterAction(registration: PluginSidebarFooterActionRegistration): CollectedCompatibilitySidebarFooterItem;
declare function getCollectedSidebarFooterItems(registrations: object): readonly CollectedSidebarFooterItem[] | null;

interface LegacyThreadPanelActionRegistration {
    id: string;
    title: string;
    icon?: string;
    component: ComponentType<_get_bb_plugin_sdk.ExperimentalThreadActionTabProps>;
    layout?: "flush" | "padded";
    run?(context: _get_bb_plugin_sdk.ExperimentalThreadTabActionContext): void | Promise<void>;
}
interface LegacyThreadHeaderActionProps {
    threadId: string;
    projectId: string;
    isCompactViewport: boolean;
}
interface LegacyThreadHeaderActionRegistration {
    id: string;
    title: string;
    component: ComponentType<LegacyThreadHeaderActionProps>;
}
type LegacyNavPanelRegistration = PluginNavPanelRegistration & {
    fixedTabs?: readonly PluginNavPanelFixedTabRegistration[];
};
type PluginNavPanelFixedTabRegistration = {
    id: string;
    panelId: string;
    title: string;
    icon: string;
    component: ComponentType<_get_bb_plugin_sdk.PluginNavPanelProps>;
    layout?: "flush" | "padded";
    experimental_target?: _get_bb_plugin_sdk.ExperimentalFixedTabTargetContract<_get_bb_plugin_sdk.JsonValue>;
};
type CollectedPluginProviderIconRegistration = Omit<PluginProviderIconRegistration, "providerKind"> & {
    providerKind: PluginProviderIconRegistration["providerKind"] | "all";
};
declare function createCommandShortcutSchema(): z.ZodObject<{
    alt: z.ZodDefault<z.ZodBoolean>;
    control: z.ZodDefault<z.ZodBoolean>;
    key: z.ZodString;
    meta: z.ZodDefault<z.ZodBoolean>;
    mod: z.ZodDefault<z.ZodBoolean>;
    shift: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
type CollectedCommandShortcut = z.infer<ReturnType<typeof createCommandShortcutSchema>> | null;
type CollectedPluginCommandRegistration = (Omit<PluginCommandRegistration, "defaultShortcut"> & {
    target: "app";
    defaultShortcut: CollectedCommandShortcut;
}) | (Omit<ExperimentalComposerCommandRegistration, "defaultShortcut"> & {
    target: "composer";
    defaultShortcut: CollectedCommandShortcut;
});
interface CollectedPluginAppRegistrations {
    homepageSections: PluginHomepageSectionRegistration[];
    settingsSections: PluginSettingsSectionRegistration[];
    appOverlays: ExperimentalAppOverlayRegistration[];
    modals: ExperimentalModalRegistration[];
    setupGuideSections: InternalDoNotUseSetupGuideSectionRegistration[];
    navPanels: LegacyNavPanelRegistration[];
    tabs: ExperimentalTabRegistration[];
    threadPanelActions: LegacyThreadPanelActionRegistration[];
    newThreadPanelActions: PluginNewThreadPanelActionRegistration[];
    composerCustomizations: ComposerCustomization[];
    pendingInteractions: PluginPendingInteractionRegistration[];
    sidebarFooterActions: PluginSidebarFooterActionRegistration[];
    experimentalSidebarFooterItems: CollectedExperimentalSidebarFooterItem[];
    threadLists: PluginThreadListRegistration[];
    experimentalSidebarNavigations: CollectedSidebarNavigationRegistration[];
    threadHeaderActions: LegacyThreadHeaderActionRegistration[];
    threadContextSegments: ExperimentalThreadContextSegmentRegistration[];
    threadInfoRows: ExperimentalThreadInfoRowRegistration[];
    threadRowMetadata: ExperimentalThreadRowMetadataRegistration<unknown>[];
    threadInfoSections: ExperimentalThreadInfoSectionRegistration[];
    threadContextCardRows: ExperimentalThreadContextCardRowRegistration[];
    threadContextCardSections: ExperimentalThreadContextCardSectionRegistration[];
    threadActions: PluginThreadActionRegistration<unknown>[];
    browserToolbarActions: ExperimentalPluginBrowserToolbarActionRegistration[];
    fileOpeners: PluginFileOpenerRegistration[];
    sourceCodeRenderers: PluginSourceCodeRendererRegistration[];
    diffRenderers: PluginDiffRendererRegistration[];
    composers: ExperimentalComposerRegistration[];
    messageDirectives: PluginMessageDirectiveRegistration[];
    codeFenceRenderers: ExperimentalCodeFenceRendererRegistration[];
    messageActions: PluginMessageActionRegistration[];
    messageMetadata: ExperimentalMessageMetadataRegistration[];
    commandPaletteActions: CollectedPluginCommandRegistration[];
    providerIcons: CollectedPluginProviderIconRegistration[];
    icons: ExperimentalIconRegistration[];
    timelineRenderers: PluginTimelineRendererRegistration[];
    environmentProviderInputs: PluginEnvironmentProviderInputsRegistration[];
    machineProviderInputs: PluginMachineProviderInputsRegistration[];
    contentScripts: PluginContentScriptRegistration[];
    threadDisplayPolicies: ExperimentalThreadDisplayPolicyResolver[];
}
interface CollectedSidebarNavigationRegistration extends ExperimentalSidebarNavigationRegistration {
    placement: ExperimentalSidebarNavigationPlacement;
}
declare function collectPluginAppRegistrations(definition: PluginAppDefinition, onWarning?: (message: string) => void, pluginId?: string): CollectedPluginAppRegistrations;

/**
 * JSON-only value passed to a host modal. It lives in the browser history
 * entry, so it must survive structured cloning and stay small (the host
 * rejects values over its size cap).
 */
type ExperimentalModalParams = null | boolean | number | string | ExperimentalModalParams[] | {
    [key: string]: ExperimentalModalParams;
};
interface ExperimentalModalOpenOptions {
    /** Header title, at most 200 characters. */
    title: string;
    /** Muted breadcrumb prefix, rendered "context / title"; at most 200 characters. */
    context?: string;
    /** JSON-only; throws when not JSON or over the size cap. */
    params?: ExperimentalModalParams;
}

interface ModalDriver {
    open(pluginId: string | null, modalId: string, options: ExperimentalModalOpenOptions): void;
    close(): void;
    subscribe(listener: () => void): () => void;
    getOpenId(pluginId: string | null): string | null;
}
declare function installModalDriver(next: ModalDriver): void;

export { adaptSidebarFooterAction, collectPluginAppRegistrations, getCollectedSidebarFooterItems, installModalDriver };
export type { CollectedCompatibilitySidebarFooterItem, CollectedExperimentalSidebarFooterItem, CollectedManagedSidebarFooterItem, CollectedPluginAppRegistrations, CollectedPluginCommandRegistration, CollectedPluginProviderIconRegistration, CollectedSidebarFooterItem, CollectedSidebarNavigationRegistration, ExperimentalSidebarFooterCommandKind, ExperimentalSidebarFooterItemRuntime, ExperimentalSidebarFooterRuntimeSnapshot, LegacyNavPanelRegistration, LegacyThreadHeaderActionRegistration, LegacyThreadPanelActionRegistration, ModalDriver };
