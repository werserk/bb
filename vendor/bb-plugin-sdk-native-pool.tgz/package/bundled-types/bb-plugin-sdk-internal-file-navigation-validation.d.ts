// Portable type declarations for `@get-bb/plugin-sdk`. Unpublished BB
// workspace contracts are flattened; public subpaths may reuse the
// package root without requiring any other @bb/* package.
//
// Confused by the API, or need a symbol that isn't here? Clone the BB repo
// and read the real source: https://github.com/get-bb/bb

/** A live file whose identity is complete without ambient route context. */
type ExperimentalLiveFileTarget = {
    kind: "workspace";
    environmentId: string;
    path: string;
    /**
     * Git revision to read instead of the working copy: `"HEAD"` or a 4–40
     * character commit SHA; other values make the target invalid. Previews
     * open read-only and are labelled with the ref; external opens ignore it
     * and open the working copy.
     */
    experimental_ref?: string;
} | {
    kind: "host";
    hostId: string;
    path: string;
} | {
    kind: "thread-storage";
    threadId: string;
    path: string;
};
/** One-based location to reveal after a live file opens. */
type ExperimentalFileLocation = {
    kind: "line";
    line: number;
    column: number | null;
} | {
    kind: "range";
    startLine: number;
    endLine: number;
};
/** Options shared by BB's preview and preferred-external file intents. */
interface ExperimentalFileOpenOptions {
    /** Restrictive artifact popup admission. Older hosts refuse; never retry without scope. */
    experimental_artifact?: {
        version: 1;
        readRoot: string;
        /** Original authoritative physical source. In-process only; copied and never persisted. */
        physicalSource: {
            hostId: string;
            canonicalReadRoot: string;
        };
        /** In-process only. Literal true admits this exact candidate before each application load attempt. */
        revalidate: (request: {
            target: ExperimentalLiveFileTarget;
            readRoot: string;
            relativePath: string;
            signal: AbortSignal;
        }) => Promise<boolean>;
        /** Mounted caller lifetime. Disposal invalidates queued/open viewers and pending reads. */
        lifetime: AbortSignal;
    };
    target: ExperimentalLiveFileTarget;
    location: ExperimentalFileLocation | null;
}

declare function normalizeExperimentalLiveFileTarget(value: unknown): ExperimentalLiveFileTarget | null;
declare function normalizeExperimentalFileLocation(value: unknown): ExperimentalFileLocation | null | undefined;
declare function normalizeExperimentalArtifactScope(target: ExperimentalLiveFileTarget, location: ExperimentalFileLocation | null, artifact: unknown): {
    version: 1;
    readRoot: string;
} | null;
declare function normalizeExperimentalFileOpenOptions(value: unknown): ExperimentalFileOpenOptions | null;
declare function normalizeExperimentalFilePreviewOptions(value: unknown): {
    options: ExperimentalFileOpenOptions;
    opener: string | null;
} | null;

export { normalizeExperimentalArtifactScope, normalizeExperimentalFileLocation, normalizeExperimentalFileOpenOptions, normalizeExperimentalFilePreviewOptions, normalizeExperimentalLiveFileTarget };
